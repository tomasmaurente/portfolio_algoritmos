package uy.edu.ucu.aed;

public interface IArbolBBAlumnos {
    public void armarSubgrupos(TArbolBB<Alumno> grupoImpares, TArbolBB<Alumno> grupoPares);
}
