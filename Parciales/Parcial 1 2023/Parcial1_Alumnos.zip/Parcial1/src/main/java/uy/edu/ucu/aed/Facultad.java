package uy.edu.ucu.aed;

public class Facultad {
    // Variable de instancia necesarias

    Facultad(/* Parámetros */) {
      // Asignar variables de instancia  
    }

    public TArbolBBAlumnos armarIndiceCurso(String cursoNombre)
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
